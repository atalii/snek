{
module Snek.Parser where

import Data.Text

import Control.Exception (Exception)
import Snek.Lex.Support
import Snek.Ast

}

%name parse
%tokentype { Token }
%error { parseError }
%monad { ParseM }

%token
  IDENT { Ident $$ }
  STR { StrLit $$ }
  INT { IntLit $$ } 
  PASS { TokPass }
  '=' { Equals }
  '+' { Plus }
  '*' { Star }
  '**' { DoubleStar }
  '//' { DoubleSlash }
  '(' { LParen }
  ')' { RParen }
  ',' { Comma }
  EOL { Newline }

%%

program : block EOL { Program $1 }
	| block { Program $1 }

block : {- empty -} { [] }
      | stmt { [$1] }
      | block EOL stmt { $1 ++ [$3] }

stmt : PASS { Pass }
     | IDENT '(' argList ')' { Builtin $1 $3 }
     | IDENT '=' expr { Assign (Loc { line = 0, column = 0}, $1) $3 }
     | IDENT '+' '=' expr { Assign (Loc { line = 0, column = 0}, $1) (Add (Lookup (Loc { line = 0, column = 0}, $1)) $4) } 

argList : {- empty -} { [] }
	| expr { [$1] }
	| argList ',' expr { $1 ++ [$3] }

expr : addn { $1 }

addn : mult { $1 }
     | addn '+' mult { Add $1 $3 }

mult : expn { $1 }
     | mult '*' expn { Mult $1 $3 }
     | mult '//' expn { Div $1 $3 }

expn : leaf { $1 }
     | leaf '**' expn { Expn $1 $3 }

leaf : STR { Use (Loc { line = 0, column = 0 }, (StrV $1)) }
     | INT { Use (Loc { line = 0, column = 0 }, (IntegerV $1)) }
     | IDENT { Lookup (Loc { line = 0, column = 0}, $1) }
     | '(' expr ')' { $2 }

{
data Err = Err Text
  deriving (Show)

instance Exception Err

type ParseM = Either Err

parseError :: [Token] -> ParseM a
parseError ts = Left $ Err $ pack $ "parse error: " ++ Prelude.show ts
}
