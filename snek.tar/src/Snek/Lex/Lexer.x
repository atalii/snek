{

module Snek.Lex.Lexer (scanFile) where

import Snek.Lex.Support
import System.IO (readFile)
import qualified Data.Text

}

%wrapper "posn"

-- See Amélia Liao's https://amelia.how/posts/parsing-layout.html#h6 for a note about character support.
%encoding "latin1"

$digit = [0-9]
$alpha = [a-zA-Z]

tokens :-
  "#".*                  ;
  \n                     { \_ -> \_ -> Newline }
  $white+                ;
  $digit+                { \_ -> IntLit . read }
  "pass"                 { \_ -> \_ -> TokPass }
  $alpha($alpha|$digit)* { \_ -> Ident . Data.Text.pack }
  \"[^\"]*\"             { \_ -> StrLit . stripQuotes . Data.Text.pack }
  "("                    { \_ -> \_ -> LParen }
  ")"                    { \_ -> \_ -> RParen }
  "="                    { \_ -> \_ -> Equals }
  ","                    { \_ -> \_ -> Comma }
  "+"                    { \_ -> \_ -> Plus }
  "*"                    { \_ -> \_ -> Star }
  "**"                   { \_ -> \_ -> DoubleStar }
  "//"                   { \_ -> \_ -> DoubleSlash }

{

stripQuotes :: Data.Text.Text -> Data.Text.Text
stripQuotes = Data.Text.tail . Data.Text.reverse . Data.Text.tail . Data.Text.reverse

scanFile :: FilePath -> IO [Token]
scanFile path = alexScanTokens <$> readFile path

}
