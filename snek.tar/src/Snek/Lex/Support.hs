module Snek.Lex.Support (Token (..), unStr) where

import Data.Text

data Token
  = Ident Text
  | StrLit Text
  | IntLit Integer
  | TokPass
  | Equals
  | Plus
  | Star
  | DoubleSlash
  | DoubleStar
  | LParen
  | RParen
  | Newline
  | Comma
  deriving (Eq, Show)

unStr :: Token -> Text
unStr (StrLit t) = t
unStr _ = error "unStr on a non-str"
