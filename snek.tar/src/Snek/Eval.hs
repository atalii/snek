{-# LANGUAGE OverloadedStrings #-}

module Snek.Eval (eval) where

import Control.Exception
import Control.Monad.State.Lazy
import Data.Map
import Data.Text
import Data.Text.IO
import Snek.Ast
import Snek.Util

data EvalExc = Unbound Name | UnknownBuiltin Text | BadTypes
  deriving (Show)

instance Exception EvalExc

type EvalState = Map Text Value

eval :: Program -> IO ()
eval (Program stmts) = evalStateT (mapM_ run stmts) (Data.Map.empty)

run :: Statement -> StateT EvalState IO ()
run (Assign name expr) = getValue expr >>= modify . Data.Map.insert (Snek.Ast.get name)
run (Builtin "print" vals) = stringify vals >>= liftIO . Data.Text.IO.putStrLn
  where
    stringify :: [Expr] -> StateT EvalState IO Text
    stringify exprs = Data.Text.intercalate " " <$> mapM (Data.Text.show <.> getValue) exprs
run (Builtin n _) = liftIO $ throwIO $ UnknownBuiltin n
run Pass = return ()

getValue :: Expr -> StateT EvalState IO Value
getValue (Use l) = return (Snek.Ast.get l)
getValue (Lookup name) = gets (Data.Map.lookup (Snek.Ast.get name)) >>= unwrapOr (Unbound name)
getValue (Add l r) = do
  l' <- getValue l
  r' <- getValue r
  addVs l' r'
getValue (Mult l r) = do
  l' <- getValue l
  r' <- getValue r
  multVs l' r'
getValue (Div l r) = do
  l' <- getValue l
  r' <- getValue r
  divVs l' r'
getValue (Expn l r) = do
  l' <- getValue l
  r' <- getValue r
  expnVs l' r'

addVs :: Value -> Value -> StateT EvalState IO Value
addVs (IntegerV lhs) (IntegerV rhs) = return $ IntegerV $ lhs + rhs
addVs (StrV lhs) (StrV rhs) = return $ StrV $ lhs <> rhs
addVs _ _ = liftIO $ throwIO $ BadTypes

multVs :: Value -> Value -> StateT EvalState IO Value
multVs (IntegerV lhs) (IntegerV rhs) = return $ IntegerV $ lhs * rhs
multVs (StrV lhs) (IntegerV rhs) = return $ StrV $ mconcat $ Prelude.take (fromIntegral rhs) $ repeat lhs
multVs lhs@(IntegerV _) rhs@(StrV _) = multVs rhs lhs
multVs _ _ = liftIO $ throwIO $ BadTypes

divVs :: Value -> Value -> StateT EvalState IO Value
divVs (IntegerV lhs) (IntegerV rhs) = return $ IntegerV $ lhs `div` rhs
divVs _ _ = liftIO $ throwIO $ BadTypes

expnVs :: Value -> Value -> StateT EvalState IO Value
expnVs (IntegerV lhs) (IntegerV rhs) = return $ IntegerV $ lhs ^ rhs
expnVs _ _ = liftIO $ throwIO $ BadTypes
