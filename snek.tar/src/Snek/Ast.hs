module Snek.Ast (Loc (..), get, tag, Program (..), Block, Name, Literal, Args, Statement (..), Expr (..), Value (..)) where

import Data.Text (Text, unpack)

data Value
  = IntegerV Integer
  | StrV Text

instance Show Value where
  show (IntegerV i) = show i
  show (StrV t) = unpack t

data Loc = Loc {line :: Integer, column :: Integer}
  deriving (Show)

type LocTagged a = (Loc, a)

get :: LocTagged a -> a
get = snd

tag :: LocTagged a -> Loc
tag = fst

data Program = Program Block
  deriving (Show)

type Block = [Statement]

type Name = LocTagged Text

type Literal = LocTagged Value

type Args = [Expr]

data Statement = Assign Name Expr | Builtin BuiltinF Args | Pass
  deriving (Show)

type BuiltinF = Text

data Expr
  = Lookup Name
  | Use Literal
  | Add Expr Expr
  | Mult Expr Expr
  | Div Expr Expr
  | Expn Expr Expr
  deriving (Show)
